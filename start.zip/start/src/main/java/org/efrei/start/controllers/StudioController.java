package org.efrei.start.controllers;

import org.efrei.start.models.Studio;
import org.efrei.start.services.StudioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/studios")
public class StudioController {

    private final StudioService service;

    @Autowired
    public StudioController(StudioService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Studio>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Studio> findById(@PathVariable int id) {
        Studio studio = service.findById(id);
        if (studio == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(studio, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Studio studio) {
        service.create(studio);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable int id, @RequestBody Studio studio) {
        Studio existingStudio = service.findById(id);
        if (existingStudio == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.update(id, studio);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable int id) {
        Studio existingStudio = service.findById(id);
        if (existingStudio == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
