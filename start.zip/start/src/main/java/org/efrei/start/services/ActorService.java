package org.efrei.start.services;

import org.efrei.start.dto.CreateActeur;
import org.efrei.start.models.Acteur;
import org.efrei.start.models.Film;
import org.efrei.start.repositories.ActorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActorService {

    private final ActorRepository repository;

    private final FilmService filmService;

    @Autowired
    public ActorService(ActorRepository repository, FilmService filmService) {
        this.repository = repository;
        this.filmService = filmService;
    }

    public List<Acteur> findAll(){
        // SELECT * from actor
        System.out.println(repository.findAll());
        return repository.findAll();
    }

    public void create(Acteur acteur) {
        // INSERT INTO actor VALUES(":firstname", ":values")
        repository.save(acteur);
    }

    public Acteur findById(String id) {
        // SELECT * FROM actor WERE id = :id
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, CreateActeur acteur) {
        Acteur updateActeur = findById(id);
        Film film = filmService.findById(acteur.getFilm_id());
        updateActeur.setNom(acteur.getNom());
        updateActeur.setPrenom(acteur.getPrenom());
        updateActeur.setFilm(film);
        repository.save(updateActeur);
    }

}
