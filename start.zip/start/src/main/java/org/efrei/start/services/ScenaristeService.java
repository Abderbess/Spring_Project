package org.efrei.start.services;

import org.efrei.start.models.Scenariste;
import org.efrei.start.repositories.ScenaristeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScenaristeService {

    private final ScenaristeRepository repository;

    @Autowired
    public ScenaristeService(ScenaristeRepository repository) {
        this.repository = repository;
    }

    public List<Scenariste> findAll() {
        return repository.findAll();
    }

    public Scenariste findById(int id) {
        return repository.findById(id).orElse(null);
    }

    public void create(Scenariste scenariste) {
        repository.save(scenariste);
    }

    public void deleteById(int id) {
        repository.deleteById(id);
    }

    public void update(int id, Scenariste scenariste) {
        Scenariste existingScenariste = findById(id);
        if (existingScenariste != null) {
            existingScenariste.setNom(scenariste.getNom());
            existingScenariste.setPrenom(scenariste.getPrenom());
            repository.save(existingScenariste);
        }
    }
}
