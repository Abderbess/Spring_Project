package org.efrei.start.controllers;

import org.efrei.start.models.Scenariste;
import org.efrei.start.services.ScenaristeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/scenaristes")
public class ScenaristeController {

    private final ScenaristeService service;

    @Autowired
    public ScenaristeController(ScenaristeService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Scenariste>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Scenariste> findById(@PathVariable int id) {
        Scenariste scenariste = service.findById(id);
        if (scenariste == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(scenariste, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Scenariste scenariste) {
        service.create(scenariste);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable int id, @RequestBody Scenariste scenariste) {
        Scenariste existingScenariste = service.findById(id);
        if (existingScenariste == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.update(id, scenariste);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable int id) {
        Scenariste existingScenariste = service.findById(id);
        if (existingScenariste == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
