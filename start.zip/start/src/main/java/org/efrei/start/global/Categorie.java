package org.efrei.start.global;

import javax.swing.*;

public enum Categorie {
    Action,
    Horreeur,
    DRAMA,
}
