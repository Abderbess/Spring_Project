/*package org.efrei.start.models;

import jakarta.persistence.*;

@Entity
public class Studio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idStudio;

    @Column(name = "nom_studio", nullable = false, length = 255)
    private String nomStudio;

    @Column(name = "pays", length = 100)
    private String pays;

    @Column(name = "annee_fondation")
    private int anneeFondation;

    @Column(name = "site_web", length = 255)
    private String siteWeb;

    public Studio(String nomStudio, String pays, int anneeFondation, String siteWeb) {
        this.nomStudio = nomStudio;
        this.pays = pays;
        this.anneeFondation = anneeFondation;
        this.siteWeb = siteWeb;
    }

    public Studio() {
    }

    // Getters and Setters

    public int getIdStudio() {
        return idStudio;
    }

    public void setIdStudio(int idStudio) {
        this.idStudio = idStudio;
    }

    public String getNomStudio() {
        return nomStudio;
    }

    public void setNomStudio(String nomStudio) {
        this.nomStudio = nomStudio;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public int getAnneeFondation() {
        return anneeFondation;
    }

    public void setAnneeFondation(int anneeFondation) {
        this.anneeFondation = anneeFondation;
    }

    public String getSiteWeb() {
        return siteWeb;
    }

    public void setSiteWeb(String siteWeb) {
        this.siteWeb = siteWeb;
    }
}
*/
package org.efrei.start.models;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Studio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idStudio;

    @Column(name = "nom_studio", nullable = false, length = 255)
    private String nomStudio;

    @Column(name = "pays", length = 100)
    private String pays;

    @Column(name = "annee_fondation")
    private int anneeFondation;

    @Column(name = "site_web", length = 255)
    private String siteWeb;

    @OneToMany(mappedBy = "studio") // This establishes the one-to-many relationship
    private List<Film> films;

    // Constructors, Getters and Setters

    public Studio(String nomStudio, String pays, int anneeFondation, String siteWeb) {
        this.nomStudio = nomStudio;
        this.pays = pays;
        this.anneeFondation = anneeFondation;
        this.siteWeb = siteWeb;
    }

    public Studio() {
    }

    // Getters and Setters

    public int getIdStudio() {
        return idStudio;
    }

    public void setIdStudio(int idStudio) {
        this.idStudio = idStudio;
    }

    public String getNomStudio() {
        return nomStudio;
    }

    public void setNomStudio(String nomStudio) {
        this.nomStudio = nomStudio;
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public int getAnneeFondation() {
        return anneeFondation;
    }

    public void setAnneeFondation(int anneeFondation) {
        this.anneeFondation = anneeFondation;
    }

    public String getSiteWeb() {
        return siteWeb;
    }

    public void setSiteWeb(String siteWeb) {
        this.siteWeb = siteWeb;
    }

    public List<Film> getFilms() {
        return films;
    }

    public void setFilms(List<Film> films) {
        this.films = films;
    }
}
