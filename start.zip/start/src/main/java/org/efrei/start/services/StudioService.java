package org.efrei.start.services;

import org.efrei.start.models.Studio;
import org.efrei.start.repositories.StudioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudioService {

    private final StudioRepository repository;

    @Autowired
    public StudioService(StudioRepository repository) {
        this.repository = repository;
    }

    public List<Studio> findAll() {
        return repository.findAll();
    }

    public Studio findById(int id) {
        return repository.findById(id).orElse(null);
    }

    public void create(Studio studio) {
        repository.save(studio);
    }

    public void deleteById(int id) {
        repository.deleteById(id);
    }

    public void update(int id, Studio studio) {
        Studio existingStudio = findById(id);
        if (existingStudio != null) {
            existingStudio.setNomStudio(studio.getNomStudio());
            existingStudio.setPays(studio.getPays());
            existingStudio.setAnneeFondation(studio.getAnneeFondation());
            existingStudio.setSiteWeb(studio.getSiteWeb());
            repository.save(existingStudio);
        }
    }
}
