package org.efrei.start.models;

import jakarta.persistence.*;
import org.efrei.start.global.Categorie;

@Entity
public class Film {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "titre", nullable = false, length = 50)
    private String titre;

    @Column(name = "resume", nullable = false, length = 1000)
    private String resume;

    @Column(name = "personnage", nullable = false, length = 200)
    private String personnage;

    @Enumerated
    private Categorie categorie;

    @ManyToOne
    @JoinColumn(name = "id_studio", nullable = false)
    private Studio studio;

    @ManyToOne
    @JoinColumn(name = "id_scenariste", nullable = false)
    private Scenariste scenariste;


    public Film(String titre, String resume, String personnage, Categorie categorie, Studio studio, Scenariste scenariste) {
        this.titre = titre;
        this.resume = resume;
        this.personnage = personnage;
        this.categorie = categorie;
        this.studio = studio;
        this.scenariste = scenariste;
    }

    public Film() {
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public String getPersonnage() {
        return personnage;
    }

    public void setPersonnage(String personnage) {
        this.personnage = personnage;
    }

    public Categorie getCategory() {
        return categorie;
    }

    public void setCategory(Categorie categorie) {
        this.categorie = categorie;
    }

    public Studio getStudio() {
        return studio;
    }

    public void setStudio(Studio studio) {
        this.studio = studio;
    }

    public Scenariste getScenariste() {
        return scenariste;
    }

    public void setScenariste(Scenariste scenariste) {
        this.scenariste = scenariste;
    }
}
